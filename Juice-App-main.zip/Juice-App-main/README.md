# Juice-App
Juice App with 3 pages UI 


![Screenshot (211)](https://user-images.githubusercontent.com/111608821/186098999-a219be65-71a0-4f6f-8610-6b52cb014481.png)
![Screenshot (212)](https://user-images.githubusercontent.com/111608821/186099009-5f7225e4-5025-41e0-bc41-02d079f96a76.png)
![Screenshot (213)](https://user-images.githubusercontent.com/111608821/186099014-7cd13e4e-0bae-4544-8754-73d277e0a203.png)
![Screenshot (214)](https://user-images.githubusercontent.com/111608821/186099021-8b5b3ace-9249-4b5e-8f72-193b6a419008.png)
![Screenshot (215)](https://user-images.githubusercontent.com/111608821/186099025-0f83d08c-69a8-4887-9736-1b92f9d3cc0a.png)
![Screenshot (216)](https://user-images.githubusercontent.com/111608821/186099027-13b927a0-5496-4c5a-a487-b06470b1afe5.png)
