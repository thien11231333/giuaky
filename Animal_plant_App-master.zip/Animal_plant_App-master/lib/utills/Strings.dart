class Strings {
  Strings._();
  static const String APP_NAME = 'aplanet';
  static const String TAG_NAME = 'we love the aplanet';
  static const String READY_TEXT = 'Ready to\nwatch?';
  static const String READY_TO_WATCH_DESC =
      "A plant is a global leader in real life entertainment.serving a passionate audience of superfans around the world with content that inspires. infroms and entertains.";
  static const START_ENJOYING = "Start Enjoying";
  static const LAST_ENJOYING = "Last Step Enjoying";
  static const choosPlan = 'Choose a Plan';
  static const weekEvent = 'week subscription';
  static const oneWeekEvent = '1 Month subscription';
  static const twoWeekEvent = '2 month subscription';
  static const threeWeekEvent = '3 month subscription';
  static const welcomeToAlpent = 'Welcome to\nNew Alpanet';
  static const relateToYou = 'Related To You';
  static const lifeWithATiger = 'Life with a Tiger';
  static const wildAnimal = 'Wild animals';
  static const bear = 'BEAR';
  static const lion = 'LION';
  static const reptiles = 'REPTILES';
  static const pets = 'PETS';

  static const quickText = 'Quick categories';
  static const lorenIpsum =
      "The tiger is the largest living cat species and a member of the genus Panthera. It is most recognisable for its dark vertical stripes on orange fur with a white underside. An apex predator, it primarily preys on ungulates, such as deer and wild boar.";
}
