# Flutter Animal Plant UI Desgin

A animal plant app fro Android.Written in Flutter.This app is static. I mean, This is a UI design. No backend.

## ScreenShots

<table>
    <tr>
        <td><img src="assets/image1.png" width="300" /></td>
        <td><img src="assets/image2.png" width="300" /></td>
        <td><img src="assets/image3.png" width="300" /></td>
    </tr>
</table>

## Android Application Package
Install APK [Click](https://drive.google.com/file/d/1wkKF5Cjk0jTL3ZkM8cdRiA-RPpwl43W7/view?usp=sharing)

## Building

-Install Flutter
- `flutter pub get`
- `flutter run`

