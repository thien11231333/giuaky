package com.example.aninal_plant

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
